--Readme document for Gabriel O'Hara, oharag@uci.edu--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

*/10
- 3/3 Summarizing tweets
- 4/4 Identifying the most popular activities
- 3/3 Adding a text earch interface

2. How long, in hours, did it take you to complete this assignment?

    21

3. What online resources did you consult when completing this assignment? (list sites like StackOverflow or specific URLs for tutorials; describe queries to Generative AI or use of AI-based code completion)

    * ChatGPT was used for the following:
        - Describing more information about Vega-Lite and providing tutorials about how to use it
        - Describing different ways to map and filter javascript data and providing tutorials about how to do it
        - Describing tables in HTML and how they function and are set up

4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?

    N/A

5. Is there anything special we need to know in order to run your code?

    Nothing needed to run the code, but activity graph has been filtered down to more critical information to look nicer